/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tutorial_2;


/**
 *
 * @author tasni
 */
public class Tutorial_2 {
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
    System.out.println("Hello world!");
    }
    
}
