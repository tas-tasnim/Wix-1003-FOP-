

import java.util.Scanner;

public class Lab2_Q1 {
    public static void main(String[] args){
        System.out.println("hdjb");
    }
    
}
